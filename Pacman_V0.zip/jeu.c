#include "jeu.h"

#include <stdio.h>
#include <stdlib.h>
#include "interfaceGraphique.h"

  char labyrinthe[9][9]={ {'#', '#', '#', '#', '#', '#', '#', '#', '#'} ,
                          {'#', 'J', 'O', 'a', '#', 'O', ' ', 'F','#'} ,
                          {'#', 'a', '#', ' ', '#', ' ', '#', ' ','#'} ,
                          {'#', ' ', '#', ' ', ' ', ' ', '#', ' ','#'},
                          {'#', ' ', '#', '#', '#', '#', '#', ' ','#'},
                          {'#', ' ', '#', ' ', ' ', ' ', '#', ' ','#'},
                          {'#', ' ', ' ', ' ', '#', ' ', '#', ' ','#'},
                          {'#', 'O', '#', 'a', '#', 'a', ' ', 'a', '#'} ,
                          {'#', '#', '#', '#', '#', '#', '#', '#', '#'} };

int dimx = 9;
int dimy = 9;

int xJoueur;
int yJoueur;

int xFantome;
int yFantome;

int initP = 0 ;
int initF = 0 ;

void afficherMur (int x, int y)
 {
  dessinerRectangle ( x    * TAILLE ,  y    * TAILLE, // Abscisse et ordonn�e du coin sup�rieur gauche
                     (x+1) * TAILLE , (y+1) * TAILLE, // Abscisse et ordonn�e du coin inf�rieur droit
                      0,                              // Proportion de rouge pour le trait de d�limitation (entre 0 et 1)
                      0,                              // Proportion de vert  pour le trait de d�limitation (entre 0 et 1)
                      1,                              // Proportion de bleu  pour le trait de d�limitation (entre 0 et 1)
                      0,                              // Proportion de rouge pour l'int�rieur du rectangle (-1 signifie pas de remplissage)
                      0,                              // Proportion de vert  pour l'int�rieur du rectangle (-1 signifie pas de remplissage)
                      1);                             // Proportion de bleu  pour l'int�rieur du rectangle (-1 signifie pas de remplissage)
 }

void afficherSol (int x, int y)
 {
  dessinerRectangle ( x    * TAILLE ,    y  * TAILLE, // Abscisse et ordonn�e du coin sup�rieur gauche
                     (x+1) * TAILLE , (y+1) * TAILLE, // Abscisse et ordonn�e du coin inf�rieur droit
                      0,                              // Proportion de rouge pour le trait de d�limitation (entre 0 et 1)
                      0,                              // Proportion de vert  pour le trait de d�limitation (entre 0 et 1)
                      0,                              // Proportion de bleu  pour le trait de d�limitation (entre 0 et 1)
                      0,                              // Proportion de rouge pour l'int�rieur du rectangle (entre 0 et 1)
                      0,                              // Proportion de vert  pour l'int�rieur du rectangle (entre 0 et 1)
                      0);                             // Proportion de bleu  pour l'int�rieur du rectangle (entre 0 et 1)
}

void afficherJoueur (int x, int y)
 {
  afficherSol(x,y);

  dessinerArcDeCercle ( (x+0.5) * TAILLE , (y+0.5) * TAILLE,       // Abscisse et ordonn�e du centre
                         0.4*TAILLE,                               // Rayon du cercle
                         45, 315,                                  // Angle de d�but et de fin (exprimes en degres)
                         1,                                        // Proportion de rouge pour le trait de d�limitation (entre 0 et 1)
                         1,                                        // Proportion de vert  pour le trait de d�limitation (entre 0 et 1)
                         0,                                        // Proportion de bleu  pour le trait de d�limitation (entre 0 et 1)
                         1,                                        // Proportion de rouge pour l'int�rieur du rectangle (entre 0 et 1)
                         1,                                        // Proportion de vert  pour l'int�rieur du rectangle (entre 0 et 1)
                         0);                                       // Proportion de bleu  pour l'int�rieur du rectangle (entre 0 et 1)
 }

void afficherPacgomme (int x, int y)
 {
  // TODO
 }

void afficherPastille (int x, int y)
 {
  // TODO
 }

void afficherFantome (int x, int y)
 {
  // TODO
 }

void afficherJeu ()
 {
  int x, y;

  effacerLaScene();

  for(x=0; x<dimx; x++)
   for (y=0; y<dimy; y++)
    {
    // printf ("x=%d - y=%d\n", x, y);

     switch (labyrinthe[y][x])
      {
       case '#': afficherMur(x,y);
                 break;

       case ' ': afficherSol (x,y);
                 break;

       case 'J': afficherSol (x,y);
                 if (!initP)
                  {
                   xJoueur = x;
                   yJoueur = y;
                   initP=1;
                  }
                 break;

       case 'F': afficherSol(x,y);
                 if (!initF)
                  {
                   xFantome = x;
                   yFantome = y;
                   initF=1;
                  }
                 break;

       case 'O': afficherPacgomme (x,y);
                 break;

       case 'a': afficherPastille (x,y);
      }
    }

   afficherJoueur  ( xJoueur  , yJoueur  );
   afficherFantome ( xFantome , yFantome );
  }

void deplacerFantome (int dir)
 {
  // TODO
 }

void deplacerJoueur (int dir)
 {
  switch (dir)
   {
    case NORD  : yJoueur ++;
                 break;

    case EST   : xJoueur ++;
                 break;

    case SUD   : yJoueur --;
                 break;

    case OUEST : xJoueur --;
                 break;
   }

  afficherJeu ();
 }
