#include "interfaceGraphique.h"
#include <stdio.h>
#include "jeu.h"
int main (int argc, char** argv)
 {
 creerFenetre ("essai",        // Titre de la fen�tre graphique
                    700,        // Largeur de la fen�tre graphique
                    700);       // Hauteur de la fen�tre graphique

  limiteDeLaFenetre (-TAILLE,        // Abscisse minimale
                      10 * TAILLE,        // Abscisse maximale
                     12*TAILLE,        // Ordonn�e minimale
                    - 4*TAILLE);       // Ordonn�e maximale


afficherJeu ();


  gererEvenements ();           // Gestion des fl�ches avec ou sans [Shift], de la barre d'espace et de la touche [Echap]

  detruireFenetre ();

  return 0;
 }
