#include "interfaceGraphique.h"

#include <gl/gl.h>
#include <windows.h>
#include <stdio.h>
#include <math.h>

/*************** Partie priv�e de la mini API ***************/

typedef struct
 {
  HINSTANCE hInstance;
  HWND      hwnd;
  HDC       hDC;
  HGLRC     hRC;
  int       fermer;
 }
 FenetreOpenGL;

FenetreOpenGL fenetreGraphiquePourAfficherDesCommandesOpenGL;

LRESULT CALLBACK WindowProc (HWND fenetre, UINT message, WPARAM wParam, LPARAM lParam);
void rafraichirFenetre ();

typedef struct
 {
  int type;

  GLfloat  fondRouge;
  GLfloat  fondVert;
  GLfloat  fondBleu;

  GLfloat  formeRouge;
  GLfloat  formeVert;
  GLfloat  formeBleu;

  GLdouble x;
  GLdouble y;
  GLdouble x2;
  GLdouble y2;
 }
 InterfaceGraphique_Segment;

typedef struct
 {
  int type;

  GLfloat  fondRouge;
  GLfloat  fondVert;
  GLfloat  fondBleu;

  GLfloat  formeRouge;
  GLfloat  formeVert;
  GLfloat  formeBleu;

  GLdouble x;
  GLdouble y;
  GLdouble x2;
  GLdouble y2;
 }
 InterfaceGraphique_Rectangle;

typedef struct
 {
  int type;

  GLfloat  fondRouge;
  GLfloat  fondVert;
  GLfloat  fondBleu;

  GLfloat  formeRouge;
  GLfloat  formeVert;
  GLfloat  formeBleu;

  GLdouble x;
  GLdouble y;
  GLdouble rayon;
 }
 InterfaceGraphique_Cercle;

typedef struct
 {
  int type;

  GLfloat  fondRouge;
  GLfloat  fondVert;
  GLfloat  fondBleu;

  GLfloat  formeRouge;
  GLfloat  formeVert;
  GLfloat  formeBleu;

  GLdouble x;
  GLdouble y;
  GLdouble rayon;
  GLdouble angleDepart;
  GLdouble angleOuverture;
 }
 InterfaceGraphique_ArcDeCercle;


typedef union
 {
  int                             type;
  InterfaceGraphique_Segment      segment;
  InterfaceGraphique_Rectangle    rectangle;
  InterfaceGraphique_Cercle       cercle;
  InterfaceGraphique_ArcDeCercle  arcDeCercle;
 }
 InterfaceGraphique_Forme;

#define __INTERFACE_GRAPHIQUE__SEGMENT__         1
#define __INTERFACE_GRAPHIQUE__RECTANGLE__       2
#define __INTERFACE_GRAPHIQUE__CERCLE__          3
#define __INTERFACE_GRAPHIQUE__ARC_DE_CERCLE__   4

typedef struct
 {
  InterfaceGraphique_Forme* forme;
  int                       nbFormes;
  GLdouble                  limiteGauche;
  GLdouble                  limiteDroite;
  GLdouble                  limiteBasse;
  GLdouble                  limiteHaute;
  GLdouble                  limiteAvant;
  GLdouble                  limiteArriere;
 }
 InterfaceGraphique_Scene;

InterfaceGraphique_Scene sceneAafficherDansLaFenetreGraphiqueOpenGLdeLaMiniAPI = {NULL, 0, -1, 1, -1, 1, -1, 1};

void ajouterForme (InterfaceGraphique_Forme f);

void afficherSegment     (InterfaceGraphique_Segment     s);
void afficherRectangle   (InterfaceGraphique_Rectangle   r);
void afficherCercle      (InterfaceGraphique_Cercle      c);
void afficherArcDeCercle (InterfaceGraphique_ArcDeCercle a);

/*************** Impl�mentation de la partie priv�e de la mini API ***************/

LRESULT CALLBACK WindowProc (HWND fenetre, UINT message, WPARAM wParam, LPARAM lParam)
 {
  switch (message)
   {
    case WM_CREATE  : return 0;
    case WM_DESTROY : PostQuitMessage (0);
                      fenetreGraphiquePourAfficherDesCommandesOpenGL.fermer=1;
                      return 0;
    default         : return DefWindowProc(fenetre,
                                           message,
                                           wParam,
                                           lParam);
   }
 }

void rafraichirFenetre ()
 {
  glClearColor (0.0f, 0.0f, 0.0f, 0.0f);
  glClear (GL_COLOR_BUFFER_BIT);

  glMatrixMode (GL_PROJECTION);
  glLoadIdentity ();

  glOrtho (sceneAafficherDansLaFenetreGraphiqueOpenGLdeLaMiniAPI.limiteGauche,
           sceneAafficherDansLaFenetreGraphiqueOpenGLdeLaMiniAPI.limiteDroite,
           sceneAafficherDansLaFenetreGraphiqueOpenGLdeLaMiniAPI.limiteBasse,
           sceneAafficherDansLaFenetreGraphiqueOpenGLdeLaMiniAPI.limiteHaute,
           sceneAafficherDansLaFenetreGraphiqueOpenGLdeLaMiniAPI.limiteAvant,
           sceneAafficherDansLaFenetreGraphiqueOpenGLdeLaMiniAPI.limiteArriere);

  glMatrixMode (GL_MODELVIEW);
  glLoadIdentity ();
  int i=0;

  for (i=0; i<sceneAafficherDansLaFenetreGraphiqueOpenGLdeLaMiniAPI.nbFormes; i++)
  {
   switch (sceneAafficherDansLaFenetreGraphiqueOpenGLdeLaMiniAPI.forme[i].type)
    {
     case __INTERFACE_GRAPHIQUE__SEGMENT__       : afficherSegment     (sceneAafficherDansLaFenetreGraphiqueOpenGLdeLaMiniAPI.forme[i].segment);     break;
     case __INTERFACE_GRAPHIQUE__RECTANGLE__     : afficherRectangle   (sceneAafficherDansLaFenetreGraphiqueOpenGLdeLaMiniAPI.forme[i].rectangle);   break;
     case __INTERFACE_GRAPHIQUE__CERCLE__        : afficherCercle      (sceneAafficherDansLaFenetreGraphiqueOpenGLdeLaMiniAPI.forme[i].cercle);      break;
     case __INTERFACE_GRAPHIQUE__ARC_DE_CERCLE__ : afficherArcDeCercle (sceneAafficherDansLaFenetreGraphiqueOpenGLdeLaMiniAPI.forme[i].arcDeCercle); break;
    }
  }

  glFlush();
  SwapBuffers(fenetreGraphiquePourAfficherDesCommandesOpenGL.hDC);
 }

void afficherSegment (InterfaceGraphique_Segment s)
 {
  glColor3f (s.formeRouge, s.formeVert, s.formeBleu);

  glBegin (GL_LINES);
   glVertex2d (s.x,  s.y);
   glVertex2d (s.x2, s.y2);
  glEnd();
 }

void afficherRectangle (InterfaceGraphique_Rectangle   r)
 {
  if ( (r.fondRouge != -1) || (r.fondVert != -1) || (r.fondBleu != -1) )
   {
    glColor3f (r.fondRouge, r.fondVert, r.fondBleu);

    glBegin (GL_QUADS);
     glVertex2d (r.x,  r.y);
     glVertex2d (r.x2, r.y);
     glVertex2d (r.x2, r.y2);
     glVertex2d (r.x,  r.y2);
    glEnd();
   }

  glColor3f (r.formeRouge, r.formeVert, r.formeBleu);

  glBegin (GL_LINE_LOOP);
   glVertex2d (r.x,  r.y);
   glVertex2d (r.x2, r.y);
   glVertex2d (r.x2, r.y2);
   glVertex2d (r.x,  r.y2);
  glEnd();
 }

void afficherCercle (InterfaceGraphique_Cercle c)
 {
  double angle;

  if ( (c.fondRouge != -1) || (c.fondVert != -1) || (c.fondBleu != -1) )
   {
    glColor3f (c.fondRouge, c.fondVert, c.fondBleu);

    glVertex2d (c.x, c.y);

    glBegin (GL_TRIANGLE_FAN);
     for (angle=0; angle <= M_PI * 2; angle += M_PI/45.0)
      glVertex2d (c.x + c.rayon * cos (angle), c.y + c.rayon * sin (angle));
    glEnd();
   }

  glColor3f (c.formeRouge, c.formeVert, c.formeBleu);

  glBegin (GL_LINE_LOOP);
   for (angle=0; angle < M_PI * 2; angle += M_PI/45.0)
    glVertex2d (c.x + c.rayon * cos (angle), c.y + c.rayon * sin (angle));
  glEnd();
 }

void afficherArcDeCercle (InterfaceGraphique_ArcDeCercle a)
 {
  double angle;

  if ( (a.fondRouge != -1) || (a.fondVert != -1) || (a.fondBleu != -1) )
   {
    glColor3f (a.fondRouge, a.fondVert, a.fondBleu);


    glBegin (GL_TRIANGLE_FAN);

        glVertex2d (a.x, a.y);

     for (angle=a.angleDepart * M_PI / 180.0; angle <= a.angleOuverture * M_PI / 180.0; angle += M_PI/36.0)
      glVertex2d (a.x + a.rayon * cos (angle), a.y + a.rayon * sin (angle));
    glEnd();
   }

  glColor3f (a.formeRouge, a.formeVert, a.formeBleu);

  glBegin (GL_LINE_LOOP);

    glVertex2d (a.x, a.y);

   for (angle=a.angleDepart * M_PI / 180.0; angle <= a.angleOuverture * M_PI / 180.0; angle += M_PI/36.0)
    glVertex2d (a.x + a.rayon * cos (angle), a.y + a.rayon * sin (angle));
  glEnd();
 }



void ajouterForme (InterfaceGraphique_Forme f)
 {
  InterfaceGraphique_Forme* tab = (InterfaceGraphique_Forme*) malloc ( (sceneAafficherDansLaFenetreGraphiqueOpenGLdeLaMiniAPI.nbFormes+1) * sizeof (InterfaceGraphique_Forme));

  if (tab == NULL)
        {
         printf ("Plus de place en memoire pour ajouter la forme !");
        }
   else {
         if (sceneAafficherDansLaFenetreGraphiqueOpenGLdeLaMiniAPI.forme != NULL)
          {
           int i;

           for (i=0; i<sceneAafficherDansLaFenetreGraphiqueOpenGLdeLaMiniAPI.nbFormes; i++)
            {
             tab[i] = sceneAafficherDansLaFenetreGraphiqueOpenGLdeLaMiniAPI.forme[i];
            }

           free (sceneAafficherDansLaFenetreGraphiqueOpenGLdeLaMiniAPI.forme);
          }

         sceneAafficherDansLaFenetreGraphiqueOpenGLdeLaMiniAPI.forme = tab;
         tab[sceneAafficherDansLaFenetreGraphiqueOpenGLdeLaMiniAPI.nbFormes] = f;
         sceneAafficherDansLaFenetreGraphiqueOpenGLdeLaMiniAPI.nbFormes += 1;
        }
 }


/*************** Impl�mentation de la partie publique de la mini API ***************/

void creerFenetre (char* titre, int largeur, int hauteur)
 {
  fenetreGraphiquePourAfficherDesCommandesOpenGL.hInstance = (HINSTANCE) GetModuleHandle (NULL);

  WNDCLASSEX wcex;
             wcex.cbSize        = sizeof(WNDCLASSEX);
             wcex.style         = CS_OWNDC;
             wcex.lpfnWndProc   = WindowProc;
             wcex.cbClsExtra    = 0;
             wcex.cbWndExtra    = 0;
             wcex.hInstance     = fenetreGraphiquePourAfficherDesCommandesOpenGL.hInstance;
             wcex.hIcon         = LoadIcon(NULL, IDI_APPLICATION);
             wcex.hCursor       = LoadCursor(NULL, IDC_ARROW);
             wcex.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
             wcex.lpszMenuName  = NULL;
             wcex.lpszClassName = "EPF";
             wcex.hIconSm       = LoadIcon(NULL, IDI_APPLICATION);

  RegisterClassEx(&wcex);

  fenetreGraphiquePourAfficherDesCommandesOpenGL.hwnd = CreateWindowEx (0,
                                                                        "EPF",
                                                                        titre,
                                                                        WS_OVERLAPPEDWINDOW,
                                                                        CW_USEDEFAULT,
                                                                        CW_USEDEFAULT,
                                                                        largeur,
                                                                        hauteur,
                                                                        NULL,
                                                                        NULL,
                                                                        fenetreGraphiquePourAfficherDesCommandesOpenGL.hInstance,
                                                                        NULL);

  ShowWindow (fenetreGraphiquePourAfficherDesCommandesOpenGL.hwnd, SW_SHOWDEFAULT);

  fenetreGraphiquePourAfficherDesCommandesOpenGL.hDC = GetDC (fenetreGraphiquePourAfficherDesCommandesOpenGL.hwnd);

  PIXELFORMATDESCRIPTOR pfd;

  ZeroMemory (&pfd, sizeof(pfd));

  pfd.nSize      = sizeof(pfd);
  pfd.nVersion   = 1;
  pfd.dwFlags    = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL |
                   PFD_DOUBLEBUFFER;
  pfd.iPixelType = PFD_TYPE_RGBA;
  pfd.cColorBits = 24;
  pfd.cDepthBits = 16;
  pfd.iLayerType = PFD_MAIN_PLANE;

  int iFormat = ChoosePixelFormat (fenetreGraphiquePourAfficherDesCommandesOpenGL.hDC, &pfd);

  SetPixelFormat (fenetreGraphiquePourAfficherDesCommandesOpenGL.hDC, iFormat, &pfd);

  fenetreGraphiquePourAfficherDesCommandesOpenGL.hRC = wglCreateContext(fenetreGraphiquePourAfficherDesCommandesOpenGL.hDC);

  wglMakeCurrent (fenetreGraphiquePourAfficherDesCommandesOpenGL.hDC, fenetreGraphiquePourAfficherDesCommandesOpenGL.hRC);

  fenetreGraphiquePourAfficherDesCommandesOpenGL.fermer=0;
 }

void detruireFenetre ()
 {
  effacerLaScene ();

  wglMakeCurrent   (NULL, NULL);
  wglDeleteContext (fenetreGraphiquePourAfficherDesCommandesOpenGL.hRC);
  ReleaseDC        (fenetreGraphiquePourAfficherDesCommandesOpenGL.hwnd, fenetreGraphiquePourAfficherDesCommandesOpenGL.hDC);
  DestroyWindow    (fenetreGraphiquePourAfficherDesCommandesOpenGL.hwnd);
 }

void gererEvenements ()
 {
  MSG  msg;
  BOOL bRet;

  do
   {
    // bRet = GetMessage( &msg, hwnd, 0, 0 );
    bRet = PeekMessage( &msg, fenetreGraphiquePourAfficherDesCommandesOpenGL.hwnd, 0, 0, PM_REMOVE );

    if (bRet != -1)
          {
           TranslateMessage(&msg);

           switch (msg.message)
            {
             // Voir http://msdn.microsoft.com/en-us/library/windows/desktop/dd375731%28v=vs.85%29.aspx
             // Voir http://msdn.microsoft.com/en-us/library/windows/desktop/ms646301%28v=vs.85%29.aspx

             case WM_KEYDOWN     : switch (msg.wParam)
                                    {
                                     case VK_UP       : if (GetKeyState(VK_SHIFT) & 0x8000)
                                                              flecheHautEtShift   ();
                                                         else flecheHaut          ();
                                                        break;
                                     case VK_DOWN     : if (GetKeyState(VK_SHIFT) & 0x8000)
                                                              flecheBasEtShift    ();
                                                         else flecheBas           ();
                                                        break;
                                     case VK_LEFT     : if (GetKeyState(VK_SHIFT) & 0x8000)
                                                              flecheGaucheEtShift ();
                                                         else flecheGauche        ();
                                                        break;
                                     case VK_RIGHT    : if (GetKeyState(VK_SHIFT) & 0x8000)
                                                              flecheDroiteEtShift ();
                                                         else flecheDroite        ();
                                                           break;
                                     case VK_SPACE    : barreEspace ();
                                                        break;
                                     case VK_ESCAPE   : fenetreGraphiquePourAfficherDesCommandesOpenGL.fermer=1;
                                    }
                                   break;

            }

           DispatchMessage(&msg);
          }

     periodique ();
     rafraichirFenetre();
     Sleep (200);  // On le fait dormir pendant 200 ms pour ne pas que �a tourne trop vite...
   }
   while ( fenetreGraphiquePourAfficherDesCommandesOpenGL.fermer == 0 );
 }

void limiteDeLaFenetre (double gauche, double droite, double bas, double haut)
 {
  sceneAafficherDansLaFenetreGraphiqueOpenGLdeLaMiniAPI.limiteGauche = gauche;
  sceneAafficherDansLaFenetreGraphiqueOpenGLdeLaMiniAPI.limiteDroite = droite;
  sceneAafficherDansLaFenetreGraphiqueOpenGLdeLaMiniAPI.limiteBasse  = bas;
  sceneAafficherDansLaFenetreGraphiqueOpenGLdeLaMiniAPI.limiteHaute  = haut;
 }

void effacerLaScene ()
 {
  if (sceneAafficherDansLaFenetreGraphiqueOpenGLdeLaMiniAPI.forme != NULL)
   {
    free (sceneAafficherDansLaFenetreGraphiqueOpenGLdeLaMiniAPI.forme);

    sceneAafficherDansLaFenetreGraphiqueOpenGLdeLaMiniAPI.forme    = NULL;
    sceneAafficherDansLaFenetreGraphiqueOpenGLdeLaMiniAPI.nbFormes = 0;
   }

  rafraichirFenetre();
 }

void dessinerSegment (double x1, double y1, double x2, double y2, float rouge, float vert, float bleu)
 {
  InterfaceGraphique_Segment s;
                             s.type       = __INTERFACE_GRAPHIQUE__SEGMENT__;
                             s.x          = x1;
                             s.y          = y1;
                             s.x2         = x2;
                             s.y2         = y2;
                             s.formeRouge = rouge;
                             s.formeVert  = vert;
                             s.formeBleu  = bleu;
                             s.fondRouge  = 0;
                             s.fondVert   = 0;
                             s.fondBleu   = 0;

  ajouterForme ( (InterfaceGraphique_Forme) s);
 }

void dessinerRectangle (double x1, double y1, double x2, double y2,
                        float rougeForme, float vertForme, float bleuForme,
                        float rougeFond,  float vertFond,  float bleuFond)
 {
  InterfaceGraphique_Rectangle r;
                               r.type       = __INTERFACE_GRAPHIQUE__RECTANGLE__;
                               r.x          = x1;
                               r.y          = y1;
                               r.x2         = x2;
                               r.y2         = y2;
                               r.formeRouge = rougeForme;
                               r.formeVert  = vertForme;
                               r.formeBleu  = bleuForme;
                               r.fondRouge  = rougeFond;
                               r.fondVert   = vertFond;
                               r.fondBleu   = bleuFond;

  ajouterForme ( (InterfaceGraphique_Forme) r);
 }

void dessinerCercle (double x,          double y,         double rayon,
                     float  rougeForme, float  vertForme, float  bleuForme,
                     float  rougeFond,  float  vertFond,  float  bleuFond)
 {
  InterfaceGraphique_Cercle c;
                            c.type       = __INTERFACE_GRAPHIQUE__CERCLE__;
                            c.x          = x;
                            c.y          = y;
                            c.rayon      = rayon;
                            c.formeRouge = rougeForme;
                            c.formeVert  = vertForme;
                            c.formeBleu  = bleuForme;
                            c.fondRouge  = rougeFond;
                            c.fondVert   = vertFond;
                            c.fondBleu   = bleuFond;

  ajouterForme ( (InterfaceGraphique_Forme) c);
 }

 void dessinerArcDeCercle (double x,          double y,         double rayon,
                           double angleDepart, double angleOuverture,
                           float  rougeForme, float  vertForme, float  bleuForme,
                           float  rougeFond,  float  vertFond,  float  bleuFond)
 {
  InterfaceGraphique_ArcDeCercle a;
                            a.type           = __INTERFACE_GRAPHIQUE__ARC_DE_CERCLE__;
                            a.x              = x;
                            a.y              = y;
                            a.rayon          = rayon;
                            a.angleDepart    = angleDepart;
                            a.angleOuverture = angleOuverture;
                            a.formeRouge     = rougeForme;
                            a.formeVert      = vertForme;
                            a.formeBleu      = bleuForme;
                            a.fondRouge      = rougeFond;
                            a.fondVert       = vertFond;
                            a.fondBleu       = bleuFond;

  ajouterForme ( (InterfaceGraphique_Forme) a);
 }
