#ifndef INTERFACEGRAPHIQUE_H_INCLUDED
#define INTERFACEGRAPHIQUE_H_INCLUDED

/* Fonctions fournies et pr�sentes dans interfaceGraphique.o */

void creerFenetre    (char* titre, int largeur, int hauteur);
void detruireFenetre ();
void gererEvenements ();

void limiteDeLaFenetre (double gauche,
                        double droite,
                        double bas,
                        double haut);
void effacerLaScene ();

void dessinerSegment   (double x1,    double y1,
                        double x2,    double y2,
                        float  rouge, float  vert, float  bleu);

void dessinerRectangle (double x1,         double y1,
                        double x2,         double y2,
                        float  rougeForme, float  vertForme, float bleuForme,
                        float  rougeFond,  float  vertFond,  float bleuFond);

void dessinerCercle (double x,          double y,         double rayon,
                     float  rougeForme, float  vertForme, float  bleuForme,
                     float  rougeFond,  float  vertFond,  float  bleuFond);

void dessinerArcDeCercle (double x,          double y,         double rayon,
                           double angleDepart, double angleOuverture,
                           float  rougeForme, float  vertForme, float  bleuForme,
                           float  rougeFond,  float  vertFond,  float  bleuFond);

/* Fonctions � r�impl�menter en conservant la signature                 */
/* Une impl�mentation de test se trouve dans implementationEvenements.c */

void flecheDroite ();
void flecheGauche ();
void flecheHaut   ();
void flecheBas    ();
void flecheDroiteEtShift ();
void flecheGaucheEtShift ();
void flecheHautEtShift   ();
void flecheBasEtShift    ();
void barreEspace ();
void periodique ();

#endif
