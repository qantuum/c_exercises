#ifndef JEU_H_INCLUDED
#define JEU_H_INCLUDED

#define TAILLE 10

#define NORD 0
#define EST 1
#define SUD 2
#define OUEST 3

void afficherMur      (int x, int y);
void afficherSol      (int x, int y);
void afficherJoueur   (int x, int y);
void afficherFantome  (int x, int y);
void afficherPacgomme (int x, int y);
void afficherPastille (int x, int y);

void afficherJeu ();

void deplacerJoueur  (int dir);
void deplacerFantome (int dir);

#endif // JEU_H_INCLUDED
