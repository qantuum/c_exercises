#include "interfaceGraphique.h"
#include "jeu.h"
#include <stdio.h>
#include <stdlib.h>

void flecheDroite ()
 {
  printf ("RIGHT\n");
  deplacerJoueur (EST);
 }

void flecheGauche ()
 {
  printf ("LEFT\n");
  deplacerJoueur(OUEST);
 }

void flecheHaut ()
 {
  printf ("UP\n");
  deplacerJoueur(SUD);
 }

void flecheBas ()
 {
  printf ("DOWN\n");
  deplacerJoueur(NORD);
 }

void flecheDroiteEtShift ()
 {
  printf ("RIGHT + SHIFT\n");
 }

void flecheGaucheEtShift ()
 {
  printf ("LEFT + SHIFT\n");
 }

void flecheHautEtShift   ()
 {
  printf ("UP + SHIFT\n");
 }

void flecheBasEtShift    ()
 {
  printf ("DOWN + SHIFT\n");
 }

void barreEspace ()
 {
  printf ("SPACE\n");
  deplacerFantome(rand()%4);

 }

 void periodique ()
  {
//  printf ("PERIODIQUE\n");
//  deplacerFantome(rand()%4);
  }

